
from motorsykkel  import Motorsykkel
def hovedprogram():
  self1 = Motorsykkel("Toyota", "3232321", 323, )
  self2=Motorsykkel
  self3=Motorsykkel
  Motorsykkel.skrivut(self1,self2,self3)
hovedprogram()
