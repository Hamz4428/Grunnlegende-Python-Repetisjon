for c in range(0, 3):
 navn=str(input("skriv inn navnet ditt: "))
 fra=str(input("hvor kommer du fra: "))
 print("hei",navn,"!""du er fra", fra)
