class Main:
  def addisjon(tall1,tall2):
    print("resultatet er: ",tall1+tall2)
    return tall1,tall2
  addisjon(132,243,)
  
   
  def subtraksjon(tall1,tall2):
    print("resultatet er: ",tall1-tall2)
    return tall1,tall2
  subtraksjon(132,243)
  def divisjon(tall1,tall2,):
    print("resultatet er: ",)
    return tall1,tall2
  addisjon(132,243,)


  def tommerTilCm(antallTommer):
    print(antallTommer*2.54)
  tommerTilCm(43)

  def skriveBeregninger():
    j=int(input("skriv inn et tall "))
    i=int(input("skriv inn et tall "))
    print(addisjon(i,j))
    l=int(input("Skriv inn et nytt tall"))
    print(tommerTilCm(l))
  skriveBeregninger()

  
  







