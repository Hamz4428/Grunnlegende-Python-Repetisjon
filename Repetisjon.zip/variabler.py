print("hallo verden")
variabel1=str(input("skriv inn et navn: "))
variabel2=(5)
variabel3=(4)
print(variabel2, variabel3, sep='\n')
variabel4=(variabel2-variabel3)
print("differanse", variabel4)
variabel5=str(input("skriv inn et nytt navn: "))
variabel6=variabel1+" og "+variabel5
print(variabel6)




