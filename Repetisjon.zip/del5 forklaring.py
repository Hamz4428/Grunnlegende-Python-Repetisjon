
def minFunksjon(): #definnerer
  for x in range(2): 
   c = 2 
  print(c)
  c += 1 
  b = 10 
  b=c
  print(b) 
  return(b) 
 
def hovedprogram(): 
 a = 42 
 b = 0 
 print(b)
 b = a 
 a = minFunksjon()
 print (b) 
 print (a) 
hovedprogram() 
 
