print("Hvor mye er 10+10?")
num1 = 10
num2 = 10
Sum = num1 + num2
print("Legger du sammen {0} og {1} får du {2}".format(num1, num2, Sum))
 
print("Hvor mye er 23+56?")
num1 = 23
num2 = 56
Sum = num1 + num2
print("Legger du sammen {0} og {1} får du {2}".format(num1, num2, Sum))
 
print("Maskinen vil be deg om å skrive inn en setning")
setning=str(input("Skriv en setning: "))
bokstav=str(input("Skriv en bokstav fra setningen : "))
print(setning.count(bokstav))

