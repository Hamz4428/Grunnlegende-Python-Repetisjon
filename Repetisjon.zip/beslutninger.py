input1=str(input("kunne du tenkt deg en brus "))
ja="ja"
nei="nei"
if input1==ja:
  print("her har du en brus ")
elif input1==nei:
  print("den er grei ")
else: 
  print("det forstod jeg ikke helt ")