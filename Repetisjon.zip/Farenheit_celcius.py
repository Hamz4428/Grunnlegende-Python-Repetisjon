F=30
print(F)
C = (5 / 9) * (F - 32)
print(C)
F=int(input("skriv inn farenheit gradene dine "))
C = (5 / 9) * (F - 32)
print(C)


