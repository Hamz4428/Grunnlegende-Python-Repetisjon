class Motorsykkel: #Lage en class som heter person 
  def __init__(self,kjor,hentkilometerstand,skrivut): # Lage en constructor person som brukes for å initialere nye objekter
    self.kjor =kjor     # Definerer attributtet navn i constructor
    self.hentkilometerstand = hentkilometerstand   # Definerer attributtet adresse i constructor
    self.skrivut =skrivut
    skrivut=print('toyota','121221',31212) # Definerer attributtet postnr i constructor

